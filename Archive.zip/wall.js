class Wall {
    constructor(options) {
        this.x = options.x;
        this.y = options.y;
        this.height = options.height;
        this.width = options.width;
        this.color = options.color;
        this.danger = options.danger;
        if (options.image) {
            this.image = new Image();
            this.image.src = options.image;
        }
    }
    render(canvas) {
        const { x, y, height, width, image } = this;
        if (image) {
            canvas.drawImage(image, x, y, height, width);
        } else {
            canvas.fillRect(x, y, width, height);
        }
    }
}